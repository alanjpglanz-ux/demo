Autarkeia Light Evaluation Package
Date: November 14, 2025

Contents (docs/):
- Executive_Summary.pdf
- Product_Overview.pdf
- README_Product.pdf
- Value_Proposition.pdf
- Licensing_Acquisition_Options.pdf
- Novelty_Claim.pdf
- IP_Summary.pdf
- Contact_OnePager.pdf
- HOEC_Diagram.png

Purpose:
This small package is designed for quick internal evaluation by acquisitions, safety, or research teams.
For the full repo (engine, dashboard, REST API, notebooks, docker wrapper), request the Full Repo Package.
