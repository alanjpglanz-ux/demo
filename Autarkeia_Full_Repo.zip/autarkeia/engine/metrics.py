"""
Metrics utilities (reference-grade skeleton).
This is intentionally lightweight for evaluation; replace with production math as needed.
"""
import numpy as np

def _norm(x):
    return float(np.linalg.norm(x) + 1e-9)

def compute_novelty_rate(X):
    """
    Placeholder novelty via reconstruction residual proxy.
    In production: PPMI -> SVD -> reconstruct -> residual / norm.
    """
    # Low-rank proxy using SVD rank-k reconstruction
    k = max(1, min(32, min(X.shape)-1))
    U, s, Vt = np.linalg.svd(X, full_matrices=False)
    S_k = np.zeros_like(s); S_k[:k] = s[:k]
    R = (U * S_k) @ Vt
    resid = _norm(X - R) / _norm(X)
    return resid

def compute_entropy(X):
    """
    Simple proxy: entropy of normalized row norms.
    """
    norms = np.linalg.norm(X, axis=1) + 1e-9
    p = norms / norms.sum()
    H = float(-(p * np.log(p)).sum())
    # normalize by log(N)
    Hn = H / float(np.log(len(p) + 1e-9))
    return Hn

def compute_subspace_shift(U_prev, X):
    """
    Distance between consecutive bases (Frobenius norm of projector difference).
    """
    if U_prev is None:
        return 1.0
    U, _, _ = np.linalg.svd(X[:min(256, X.shape[0])], full_matrices=False)
    P_prev = U_prev @ U_prev.T
    P = U @ U.T
    return float(np.linalg.norm(P - P_prev, 'fro') / (np.linalg.norm(P_prev, 'fro') + 1e-9))

def compute_flip_rate(t, T):
    """
    Proxy flip-rate (monotone decay). Replace with label flip detection.
    """
    if T <= 1:
        return 0.0
    return float(max(0.0, 1.0 - t / max(1, T-1)))

def compute_completion(I_norm, H_norm, d_sub, flip_rate, lambdas=(0.4, 0.2, 0.2, 0.2)):
    l1,l2,l3,l4 = lambdas
    val = 1.0 - (l1*I_norm + l2*H_norm + l3*d_sub + l4*flip_rate)
    return float(max(0.0, min(1.0, val)))
