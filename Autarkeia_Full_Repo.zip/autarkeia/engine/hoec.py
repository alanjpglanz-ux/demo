"""
Higher-Order Emergent Calculus (HOEC) — reference skeleton
Computes first/second differences, curvature proxies, hysteresis lag, and EOI.
"""
import numpy as np

def _diff(x):
    x = np.array(x, dtype=float)
    return np.diff(x).tolist()

def _diff2(x):
    x = np.array(x, dtype=float)
    return np.diff(x, n=2).tolist()

def _curvature(x):
    d2 = np.array(_diff2(x), dtype=float)
    return float(np.mean(np.abs(d2))) if len(d2) else 0.0

def _best_lag(a, b, max_lag=3):
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    best = {"lag": 0, "corr": 0.0}
    for lag in range(-max_lag, max_lag+1):
        if lag < 0:
            a_l, b_l = a[:lag], b[-lag:]
        elif lag > 0:
            a_l, b_l = a[lag:], b[:-lag]
        else:
            a_l, b_l = a, b
        if len(a_l) < 2 or len(b_l) < 2:
            continue
        c = np.corrcoef(a_l, b_l)[0,1]
        if np.isnan(c):
            continue
        if abs(c) > abs(best["corr"]):
            best = {"lag": lag, "corr": float(c)}
    return best

def compute_eoi(I_series, C_series):
    """
    Simple EOI: combines monotonicity, smoothness, curvature penalty, and lag alignment.
    """
    I = np.array(I_series, dtype=float)
    C = np.array(C_series, dtype=float)

    # monotonicity scores (I descending, C ascending)
    mono_I = float(np.mean(np.diff(I) <= 0)) if len(I) > 1 else 1.0
    mono_C = float(np.mean(np.diff(C) >= 0)) if len(C) > 1 else 1.0

    # smoothness via small average absolute first differences
    sm_I = 1.0 - float(np.mean(np.abs(np.diff(I)))) if len(I) > 1 else 1.0
    sm_C = 1.0 - float(np.mean(np.abs(np.diff(C)))) if len(C) > 1 else 1.0

    # curvature penalty
    curv_pen = 1.0 - 0.5 * (_curvature(I) + _curvature(C))

    # lag/hysteresis correlation (favor positive alignment)
    lag = _best_lag(-I, C)  # collapse of -I should align with rise of C
    lag_score = (lag["corr"] + 1) / 2.0  # map [-1,1] -> [0,1]

    # combine
    comps = [mono_I, mono_C, sm_I, sm_C, curv_pen, lag_score]
    EOI = float(max(0.0, min(1.0, np.mean(comps))))
    return EOI, lag

def compute_hoec_all(I_series, C_series):
    dI = _diff(I_series); d2I = _diff2(I_series)
    dC = _diff(C_series); d2C = _diff2(C_series)
    curv_I = _curvature(I_series)
    curv_C = _curvature(C_series)
    EOI, lag = compute_eoi(I_series, C_series)
    return {
        "iters": list(range(len(I_series))),
        "I_dot": list(map(float, I_series)),
        "completion": list(map(float, C_series)),
        "dI": list(map(float, dI)),
        "d2I": list(map(float, d2I)),
        "dC": list(map(float, dC)),
        "d2C": list(map(float, d2C)),
        "curvature_I": float(curv_I),
        "curvature_C": float(curv_C),
        "lag_hysteresis": {"lag": int(lag["lag"]), "corr": float(lag["corr"])},
        "EOI": float(EOI)
    }
