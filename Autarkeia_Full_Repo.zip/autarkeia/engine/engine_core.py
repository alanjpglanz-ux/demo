"""
Autarkeia core API (skeleton suitable for due diligence)
Note: This is a simplified reference implementation demonstrating the API surface.
"""

import json, os
import numpy as np
from .metrics import compute_novelty_rate, compute_completion, compute_entropy, compute_subspace_shift, compute_flip_rate
from .hoec import compute_hoec_all

class AutarkeiaMetrics:
    def __init__(self, snapshots):
        """
        snapshots: list of 2D arrays (e.g., embeddings at each time step), shape [T][N, D]
        """
        self.snapshots = snapshots
        self._ledger = []
        self._hoec = None

    @classmethod
    def from_embeddings(cls, snapshots):
        """Construct from a sequence of embedding/activation matrices."""
        return cls(snapshots)

    @classmethod
    def from_corpus(cls, corpus_lines, window=5, dim=128, steps=6, seed=42):
        """
        Placeholder: builds toy representations from a corpus-like source.
        In production, replace with PPMI->SVD pipeline and anchor-promotion loop.
        """
        rng = np.random.default_rng(seed)
        snapshots = [rng.normal(size=(512, dim)) for _ in range(steps)]
        return cls(snapshots)

    def run(self, max_iters=5, out_dir=None):
        """
        Compute per-step metrics on the given snapshots, produce a ledger and HOEC summary.
        """
        T = len(self.snapshots)
        last_basis = None
        for t in range(T):
            X = self.snapshots[t]
            i_dot = compute_novelty_rate(X)
            H = compute_entropy(X)
            d_sub = compute_subspace_shift(last_basis, X)
            flips = compute_flip_rate(t, T)  # placeholder proxy
            self._ledger.append({
                "iter": t,
                "I_dot": float(i_dot),
                "label_entropy": float(H),
                "subspace_shift": float(d_sub),
                "flip_rate": float(flips),
            })
            # cache basis
            U, _, _ = np.linalg.svd(X[:min(256, X.shape[0])], full_matrices=False)
            last_basis = U

        # Add completion after raw metrics are known
        for row in self._ledger:
            comp = compute_completion(
                row["I_dot"], row["label_entropy"], row["subspace_shift"], row["flip_rate"]
            )
            row["completion"] = float(comp)

        # HOEC from I_dot and completion sequences
        I_series  = [r["I_dot"] for r in self._ledger]
        C_series  = [r["completion"] for r in self._ledger]
        self._hoec = compute_hoec_all(I_series, C_series)

        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
            with open(os.path.join(out_dir, "ledger.json"), "w") as f:
                json.dump({"iterations": self._ledger}, f, indent=2)
            with open(os.path.join(out_dir, "hoec.json"), "w") as f:
                json.dump(self._hoec, f, indent=2)

        return self

    def summary(self):
        if not self._ledger:
            return {"status": "not_run"}
        last = self._ledger[-1]
        return {
            "last_iter": last["iter"],
            "I_dot": last["I_dot"],
            "completion": last["completion"],
            "entropy": last["label_entropy"],
            "subspace_shift": last["subspace_shift"],
            "flip_rate": last["flip_rate"],
            "EOI": float(self._hoec.get("EOI", 0.0)) if self._hoec else None,
            "status": "equilibrium" if (last["completion"] > 0.9 and last["I_dot"] < 0.15) else "reorganizing"
        }

    def series(self):
        return self._ledger

    def hoec(self):
        return self._hoec or {}
