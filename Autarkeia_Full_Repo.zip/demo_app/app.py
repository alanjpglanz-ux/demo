from flask import Flask, render_template, jsonify
import os, json

app = Flask(__name__)
DATA_DIR = os.environ.get("AUTARKEIA_DATA", "demo_app")

def _load_json(name):
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)

@app.route("/")
def index():
    ledger = _load_json("ledger.json")
    hoec = _load_json("hoec.json")
    last = (ledger.get("iterations") or [{}])[-1] if ledger else {}
    status = "Equilibrium ✅" if (last.get("completion",0) > 0.9 and last.get("I_dot",1) < 0.15) else "Reorganizing ⚠️"
    return render_template("index.html", last=last, hoec=hoec, status=status)

@app.route("/api/summary")
def api_summary():
    ledger = _load_json("ledger.json")
    hoec = _load_json("hoec.json")
    return jsonify({"ledger": ledger, "hoec": hoec})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8008, debug=False)
