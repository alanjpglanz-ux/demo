import numpy as np
from autarkeia.engine.engine_core import AutarkeiaMetrics

def test_run_shapes():
    series = [np.random.randn(128, 64) for _ in range(4)]
    m = AutarkeiaMetrics.from_embeddings(series).run()
    s = m.summary()
    assert 'completion' in s and 'I_dot' in s
